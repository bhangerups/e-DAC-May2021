//WAP to addition of single matrix
import java.util.*;
class SumSingleMatrix
{
	public static void main(String args[])
	{
		int a[]=new int[5];
		int sum=0;
		System.out.println("Enter values of first matrix :");
		Scanner sc =new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("Sum of matrix :");
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		System.out.print(sum+" ");
	}
}