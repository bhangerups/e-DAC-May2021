//WAP to find Area of rectangle using class 
class Rectangle
{
	int length;
	int breadth;
	void getdata(int x,int y)
	{
		length=x;
		breadth=y;
	}
	int area()
	{
		int area=length*breadth;
		return area;
	}
}

class Main
{
	public static void main(String args[])
	{
		Rectangle rect=new Rectangle();
		rect.getdata(10,20);
		int a=rect.area();
		System.out.print("Area of rectangle :"+a);
	}
}
		