//WAP to find Area of circle using class 
class Main1Method2
{
	float radius;
	
	void getdata(float x)
	{
		radius=x;
	}
	float area()
	{
		float area=22/7*(radius*radius);
		return area;
	}
	
	public static void main(String args[])
	{
		Main1Method2 c=new Main1Method2();
		c.getdata(20.23F);
		System.out.print("Area of circle :"+c.area());
	}
}
		