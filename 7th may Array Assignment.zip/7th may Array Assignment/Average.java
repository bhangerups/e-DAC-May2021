//WAP to calculate average of single dimentional array elements
import java.util.*;
class Average
{
	public static void main(String args[])
	{
		int a[]=new int[5];
		int sum=0;
		System.out.println("Enter values of first matrix :");
		Scanner sc =new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("average  of matrix Elements :");
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		int n =a.length;
		//System.out.print(n+" ");
		int avg=sum/n;
		System.out.print(avg+" ");
	}
}