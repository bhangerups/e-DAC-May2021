//WAP to addition of single matrix
import java.util.*;
class MulSingleMatrix
{
	public static void main(String args[])
	{
		int a[]=new int[5];
		int mul=1;
		System.out.println("Enter values of first matrix :");
		Scanner sc =new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("Sum of matrix :");
		for(int i=0;i<a.length;i++)
		{
			mul=mul*a[i];
		}
		System.out.print(mul+" ");
	}
}