class Test
{
	public void display()
	{
		System.out.println("In display func");
	}
	public static void main(String args[])
	{
		Test t1= new Test();
		t1.display();
	}
}
	