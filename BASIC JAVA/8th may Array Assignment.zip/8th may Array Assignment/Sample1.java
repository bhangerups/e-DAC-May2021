//WAP to display user defined values by using constructor
class Sample
{
	int a,b;
	Sample(int x,int y)
	{
		a=x;
		b=y;
	}
	void sum()
	{
		System.out.println("Sum :"+(a+b));
	}
}
class Sample1
{
	public static void main(String args[])
	{
		Sample s1= new Sample(10,20);
		s1.sum();
	}
}
	
	