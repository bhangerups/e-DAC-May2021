//Constructor example 
class F
{
	F()
	{
		System.out.println("In default constructor");
	}
	F(int x,int y)
	{
		System.out.println("X :"+x);
		System.out.println("X :"+y);	
	}
}
public class Constructor
{
	public static void main(String args[])
	{
		
		F f1= new F();
		System.out.println("Parameterised Constructor");
		F f2= new F(10,20);
	}
}