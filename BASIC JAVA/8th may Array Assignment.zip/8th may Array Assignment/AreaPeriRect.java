// WAP to perform area of rectangle and perimeter of rectangle
class Rectangle
{
	int length;
	int breadth;
	public void getdata(int x,int y)
	{
		length=x;
		breadth=y;
	}
	//function for area calculation
	public int area()
	{
		int  area=length*breadth;
		return area;
	}
	//perimeter of rectangle
	public int perimeterRect()
	{
		int perimeter=2*(length+breadth);
		return perimeter;
	}
}

class AreaPeriRect
{
	public static void main(String args[])
	{
		Rectangle rect= new Rectangle();
		rect.getdata(10,20);
		int a=rect.area();
		System.out.println("Area of rectangle : "+a);
		int p=rect.perimeterRect();
		System.out.println("perimeter of rectangle : "+p);
	}
}

	