class Test
{
	void show()
	{
		System.out.println("Hello");
	}
	void show1()
	{
		System.out.println("Hi");
	}
}

class Test1
{
	public static void main(String args[])
	{
		Test t= new Test();
		t.show();
		Test t2 =new Test();
		t.show1();
	}
}