class F
{
	void show()
	{
		System.out.println("In Show function");
	}
	int  show(int x)
	{
		x=2;
		return x;
		
	}
	float show(float x,float y)
	{
		float z=x+y;
		return z;
	}
}

public class FunctionOverloading
{
	public static void main(String args[])
	{
		F obj= new F();
		obj.show();
		int j=obj.show(10);
		System.out.println("j:"+j);
		float p=obj.show(10.2F,10.30F);
		System.out.println("Z="+p);
	}
}
		