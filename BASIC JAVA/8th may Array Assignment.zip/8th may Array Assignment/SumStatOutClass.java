//Static varible in different class 
class  S
{
	static int sum(int x,int y)
	{
		return x+y;
	}
	void display(int r)
	{
		System.out.println("Result sum:"+r);
	}
}

public class SumStatOutClass
{
	public static void main(String args[])
	{
		S s1=new S();
		int res=S.sum(10,20);
		s1.display(res);
	}
}
		