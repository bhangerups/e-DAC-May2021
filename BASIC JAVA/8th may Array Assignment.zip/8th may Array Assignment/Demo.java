//Private in different class  not accessible 
 class AccesModifiersExamples
{
	private int data;
	void display()
	{
		System.out.println("In display function");
	}
		
}
public class Demo
{
	public static void main(String args[])
	{
		AccesModifiersExamples c=new  AccesModifiersExamples();
		c.data=10;
		System.out.println(c.data);
		c.display();
	}
}