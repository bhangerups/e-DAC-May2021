//Access Modifiers
//Private in same class
public class AccesModifiersExamples
{
	private int data;
	public static void main(String args[])
	{
		AccesModifiersExamples c=new  AccesModifiersExamples();
		c.data=10;
		System.out.println(c.data);
	}
}
