//static in same class
class SumStatSameClass
{
	static int sum(int i,int j)
	{
		return i+j;
	}
	 static void show(int x)
	{
		System.out.println("Result:"+x);
	}
	public static void main(String args[])
	{
		int r=sum(10,20);
		show(r);
	}
}

	