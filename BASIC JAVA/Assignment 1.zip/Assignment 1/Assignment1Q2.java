/*2. Write a Java program to print the sum of two numbers. 
Test Data: 74 + 36
*/

import java.util.Scanner;
public class Assignment1Q2
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
int number1=sc.nextInt();
int number2=sc.nextInt();
int sum=number1+number2;
System.out.println("Test Data 74+36");
System.out.println(sum);
}
}

/*Output
74+36
108
*/