/*
3. Write a Java program to divide two numbers and print on the screen. 
Test Data : 50/3
Expected Output : 16
*/
import java.util.Scanner;
public class Assignment1Q3
{
public static void main(String args[])
{
System.out.println("Enter two elements:");
Scanner sc=new Scanner(System.in);
int number1=sc.nextInt();
int number2=sc.nextInt();
int Divide=number1/number2;
System.out.println("Division:"+Divide);
}
}
