//WAP tp print "Hello" on screen and then print your name on separate line 
class Assignment1Q1
{
public static void main(String args[])
{
System.out.println("Hello");
System.out.println("Rupali Bhange");
}
}

/* Output :
Hello
Rupali Bhange
*/