/*
12. Write a Java program that takes three numbers as input to calculate and print the 
average of the numbers. 
*/
import java.util.*;
class Assignment1Q12
{
public static void main(String args[])
{
Scanner sc = new Scanner(System.in);
System.out.print("Enter three Numbers :");
int number1=sc.nextInt();
int number2=sc.nextInt();
int number3=sc.nextInt();
float average=(number1+number2+number3)/3;
System.out.println("Average :  "+average);	
}
}

