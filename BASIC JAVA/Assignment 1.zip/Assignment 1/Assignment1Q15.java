//15. Write a Java program to swap two variables.

import java.util.*;
class Assignment1Q15
{
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter two numbers : ");
	int number1=sc.nextInt();
	int number2=sc.nextInt();
	int temp=number1;
	number1=number2;
	number2=temp;
	System.out.println("Number after swapping :" +number1+" "+number2);
}
}

