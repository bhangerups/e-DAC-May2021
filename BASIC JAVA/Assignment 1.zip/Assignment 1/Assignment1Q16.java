/*
16. Write a Java program to print a face. 
Expected Output
*/
import java.util.*;
class Assignment1Q16
{
public static void main(String args[])
{
	System.out.println(" +''''''''+");
	System.out.println("[|  0   0 |]");
	System.out.println(" |    ^   |");
	System.out.println(" |   '_'  |");
	System.out.println(" +========+");
}
}
