/*
6. Write a Java program to print the sum (addition), multiply, subtract, divide and 
remainder of two numbers. 
Test Data:
Input first number: 125
Input second number: 24
Expected Output :
125 + 24 = 149
125 - 24 = 101
125 x 24 = 3000125 / 24 = 5
125 mod 24 = 5
*/
import java.util.*;
class Assignment1Q6
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.print("Input First Number :");
int number1=sc.nextInt();
System.out.print("Input Second Number :");
int number2=sc.nextInt();
System.out.println("Addition :"+(number1+number2));
System.out.println("Substraction :"+(number1-number2));
System.out.println("Multiplication :"+(number1*number2));
System.out.println("Division :"+(number1/number2));
System.out.println("Modulo :"+(number1%number2));
}
}
