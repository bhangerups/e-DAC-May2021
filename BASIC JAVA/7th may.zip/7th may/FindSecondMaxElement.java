//WAp to print Second largest element from array
import java.util.*;
class FindSecondMaxElement
{
	public static void main(String args[])
	{
		System.out.print("Enter size of array :");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		//int b[]=new int[n];
		System.out.print("Enter array Elements :");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		//sorting and swapping of array
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;i<n;i++)
			{
				if(arr[i]>arr[j+1])
				{
					int temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		System.out.println("Second Largest Element :  "+arr[n-2]);
	}	
}

/*int max=arr[0];
		for(int i=0;i<n;i++)
		{
		if(arr[i]>max)
			max=arr[i];
			b[i]=max;
		}
		System.out.println("Maximum element in array :"+max);
        for(int i=0;i<n;i++)
		{
			System.out.println(b[i]);
		}
		System.out.println();
		System.out.println(b[n-2]);*/