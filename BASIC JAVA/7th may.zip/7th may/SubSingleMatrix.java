//WAP to addition of single matrix
import java.util.*;
class SubSingleMatrix
{
	public static void main(String args[])
	{
		int a[]=new int[5];
		int sub=0;
		System.out.println("Enter values of first matrix :");
		Scanner sc =new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.print("Sub of matrix :");
		for(int i=0;i<a.length;i++)
		{
			sub=sub-a[i];
		}
		System.out.print(sub+" ");
	}
}