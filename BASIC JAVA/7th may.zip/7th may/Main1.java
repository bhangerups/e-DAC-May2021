//WAP to find Area of circle using class 
class AreaCircle
{
	float radius;
	void getdata(float x)
	{
		radius=x;
	}
	float area()
	{
		float area=22/7*(radius*radius);
		return area;
	}
}

class Main1
{
	public static void main(String args[])
	{
		AreaCircle c=new AreaCircle();
		c.getdata(20.23F);
		float a=c.area();
		System.out.print("Area of circle :"+a);
	}
}
		