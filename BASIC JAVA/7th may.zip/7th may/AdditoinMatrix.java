//WAP to additon of elements 2*2 matrix
import java.util.*;
class AdditoinMatrix
{
	public static void main(String args[])
	{
		int a[][]=new int[2][2];
		int b[][]=new int[2][2];
		int c[][]=new int[2][2];
		//int sum=0;
		System.out.println("Enter values of first matrix :");
		Scanner sc =new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				a[i][j]=sc.nextInt();
			}
			//System.out.println();
		}
		
		System.out.println("Enter values of second matrix :");
		for(int i=0;i<b.length;i++)
		{
			for(int j=0;j<b[i].length;j++)
			{
				b[i][j]=sc.nextInt();
			}
			//System.out.println();
		}
		System.out.println("Sum of matrix :");
		for(int i=0;i<c.length;i++)
		{
			for(int j=0;j<c[i].length;j++)
			{
				c[i][j]=a[i][j]+b[i][j];	
			}	
		//	System.out.println();
		}
		for(int x[]:c)
		{
			for(int y:x)
			{
				System.out.print(y+" ");
			}
		}
	}
}